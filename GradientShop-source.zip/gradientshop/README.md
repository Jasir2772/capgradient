# GradientShop — o'rnatish qo'llanmasi

## 1. Talablar
- Server: **Paper 1.20.4**
- Java 17+
- **PlayerPoints** plagini avval o'rnatilgan bo'lishi shart (token tizimi shu orqali ishlaydi)

## 2. Build qilish (kompyuteringizda, internet bilan)
Bu loyihani menga hisoblash muhitida internet yo'qligi sababli jar faylga aylantira olmadim — shuning uchun manba kodni (source) beryapman. Build qilish uchun:

1. Kompyuteringizda **Java 17 JDK** va **Maven** o'rnatilgan bo'lishi kerak.
2. Ushbu papkani (`gradientshop/`) biror joyga oching.
3. Terminalda shu papka ichida:
   ```
   mvn clean package
   ```
4. `target/GradientShop.jar` fayli hosil bo'ladi — shuni serveringizning `plugins/` papkasiga tashlang, `PlayerPoints.jar` bilan birga.
5. Serverni qayta ishga tushiring.

Agar Maven/JDK o'rnatishda qiynalsangiz — bu jarayonni ham video/qadam-baqadam tushuntirib bera olaman, faqat aytib qo'ying.

## 3. Foydalanish
- `/gshop` — bosh menyuni ochadi
- `/gshop reload` — config.yml'ni qayta yuklaydi (OP kerak)

## 4. Hammasi config.yml orqali boshqariladi
`src/main/resources/config.yml` faylida:
- Har bir gradient/font/name color: **nomi, narxi, rangi** — hammasi tahrirlanadi
- Yangi gradient/font/name color qo'shish uchun shunchaki yangi qator qo'shasiz (yuqoridagilar namuna)
- Barcha matnlar (xabarlar, menyu sarlavhalari) ham shu faylda, o'zbek tilida

## 5. Tuzilma (nima qayerda)
- `gui/` — barcha menyular (Bosh menyu, Gradient/Font/NameColor do'konlari, Sozlamalar, Olinganlar, Profil, Top)
- `data/` — o'yinchi ma'lumotlari (playerdata.yml da saqlanadi) va config o'qish
- `listener/` — chat gradient/font qo'llash, inventar bosishlar, join/quit
- `economy/` — PlayerPoints bilan bog'lanish
- `util/` — gradient va font matematikasi

## 6. Keyingi qadam
Test qiling — agar biror joyda xato chiqsa yoki nimadir kutilganidek ishlamasa (masalan xato xabari, menyu ochilmasligi), aynan shu xabarni menga tashlang — darhol tuzataman.
