package com.exez.gradientshop.data;

public class ShopEntry {
    public final String id;
    public final String name;
    public final String from;   // gradient uchun boshlang'ich hex, namecolor uchun yagona hex
    public final String to;     // faqat gradient uchun
    public final String style;  // faqat font uchun (DEFAULT/BOLD_ITALIC/SMALL_CAPS)
    public final long price;

    public ShopEntry(String id, String name, String from, String to, String style, long price) {
        this.id = id;
        this.name = name;
        this.from = from;
        this.to = to;
        this.style = style;
        this.price = price;
    }
}
