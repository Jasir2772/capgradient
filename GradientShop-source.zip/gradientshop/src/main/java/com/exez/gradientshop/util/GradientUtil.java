package com.exez.gradientshop.util;

import net.md_5.bungee.api.ChatColor;

/**
 * Ikki hex rang orasida matnni harf-harf gradient qilib bo'yaydi.
 */
public class GradientUtil {

    public static String applyGradient(String text, String fromHex, String toHex) {
        if (text == null || text.isEmpty()) return text;
        char[] chars = text.toCharArray();
        int length = Math.max(chars.length - 1, 1);

        int[] from = hexToRgb(fromHex);
        int[] to = hexToRgb(toHex);

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < chars.length; i++) {
            double ratio = (double) i / length;
            int r = (int) (from[0] + ratio * (to[0] - from[0]));
            int g = (int) (from[1] + ratio * (to[1] - from[1]));
            int b = (int) (from[2] + ratio * (to[2] - from[2]));
            String hex = String.format("#%02X%02X%02X", r, g, b);
            result.append(ChatColor.of(hex)).append(chars[i]);
        }
        return result.toString();
    }

    public static int[] hexToRgb(String hex) {
        hex = hex.replace("#", "");
        int r = Integer.parseInt(hex.substring(0, 2), 16);
        int g = Integer.parseInt(hex.substring(2, 4), 16);
        int b = Integer.parseInt(hex.substring(4, 6), 16);
        return new int[]{r, g, b};
    }

    public static String single(String text, String hex) {
        return ChatColor.of("#" + hex.replace("#", "")) + text;
    }
}
