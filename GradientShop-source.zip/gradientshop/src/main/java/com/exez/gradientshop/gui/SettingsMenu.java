package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class SettingsMenu extends AbstractMenu {

    public SettingsMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        inventory = Bukkit.createInventory(this, 27, color(plugin.getConfig().getString("gui-titles.settings")));
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());

        int gradSlot = navSlot("menus.settings.gradient-toggle", 10);
        int fontSlot = navSlot("menus.settings.font-toggle", 12);
        int randomSlot = navSlot("menus.settings.random-toggle", 14);
        int nameColorSlot = navSlot("menus.settings.namecolor-toggle", 16);
        int shopLinkSlot = navSlot("menus.settings.namecolor-shop-link", 22);
        int backSlot = navSlot("menus.settings.back", 18);
        int homeSlot = navSlot("menus.settings.home", 26);

        inventory.setItem(gradSlot, navToggleItem("menus.settings.gradient-toggle", data.isGradientEnabled(), Material.LIME_DYE, Material.GRAY_DYE, "Gradient"));
        inventory.setItem(fontSlot, navToggleItem("menus.settings.font-toggle", data.isFontEnabled(), Material.LIME_DYE, Material.GRAY_DYE, "Font"));
        inventory.setItem(randomSlot, navToggleItem("menus.settings.random-toggle", data.isRandomEnabled(), Material.LIME_DYE, Material.GRAY_DYE, "Random"));
        inventory.setItem(nameColorSlot, navToggleItem("menus.settings.namecolor-toggle", data.isNameColorEnabled(), Material.LIME_DYE, Material.GRAY_DYE, "Name color"));

        inventory.setItem(shopLinkSlot, navItem("menus.settings.namecolor-shop-link", Material.PURPLE_DYE, "&dName Color Shop", List.of("&7Do'konga o'tish.")));
        inventory.setItem(backSlot, navItem("menus.settings.back", Material.RED_DYE, "&cOrqaga", null));
        inventory.setItem(homeSlot, navItem("menus.settings.home", Material.CHEST, "&6Bosh menyu", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());

        if (slot == navSlot("menus.settings.gradient-toggle", 10)) {
            data.setGradientEnabled(!data.isGradientEnabled());
        } else if (slot == navSlot("menus.settings.font-toggle", 12)) {
            data.setFontEnabled(!data.isFontEnabled());
        } else if (slot == navSlot("menus.settings.random-toggle", 14)) {
            data.setRandomEnabled(!data.isRandomEnabled());
            if (data.isRandomEnabled()) data.setGradientEnabled(true);
        } else if (slot == navSlot("menus.settings.namecolor-toggle", 16)) {
            data.setNameColorEnabled(!data.isNameColorEnabled());
        } else if (slot == navSlot("menus.settings.namecolor-shop-link", 22)) {
            openMenu(new NameColorShopMenu(plugin, player, 1));
            return;
        } else if (slot == navSlot("menus.settings.back", 18) || slot == navSlot("menus.settings.home", 26)) {
            openMenu(new MainMenu(plugin, player));
            return;
        } else {
            return;
        }
        playConfigSound("sounds.select");
        plugin.getDataManager().save(data);
        openMenu(new SettingsMenu(plugin, player));
    }
}
