package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class SettingsMenu extends AbstractMenu {

    public SettingsMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        inventory = Bukkit.createInventory(this, 27, color(plugin.getConfig().getString("gui-titles.settings")));
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());

        inventory.setItem(10, toggleItem("Gradient", data.isGradientEnabled()));
        inventory.setItem(12, toggleItem("Font", data.isFontEnabled()));
        inventory.setItem(14, toggleItem("Random", data.isRandomEnabled()));
        inventory.setItem(16, toggleItem("Name color", data.isNameColorEnabled()));

        inventory.setItem(22, item(Material.NAME_TAG, "&dName Color Shop", List.of("&7Do'konga o'tish.")));
        inventory.setItem(18, item(Material.RED_DYE, "&cOrqaga", null));
        inventory.setItem(26, item(Material.CHEST, "&6Bosh menyu", null));
    }

    private ItemStack toggleItem(String label, boolean on) {
        Material mat = on ? Material.LIME_DYE : Material.GRAY_DYE;
        String state = on ? "&aON" : "&cOFF";
        return item(mat, "&f" + label + ": " + state, List.of("&7Bosib holatni almashtiring."));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        switch (slot) {
            case 10 -> data.setGradientEnabled(!data.isGradientEnabled());
            case 12 -> data.setFontEnabled(!data.isFontEnabled());
            case 14 -> {
                data.setRandomEnabled(!data.isRandomEnabled());
                if (data.isRandomEnabled()) data.setGradientEnabled(true);
            }
            case 16 -> data.setNameColorEnabled(!data.isNameColorEnabled());
            case 22 -> { openMenu(new NameColorShopMenu(plugin, player, 1)); return; }
            case 18, 26 -> { openMenu(new MainMenu(plugin, player)); return; }
            default -> { return; }
        }
        plugin.getDataManager().save(data);
        openMenu(new SettingsMenu(plugin, player));
    }
}
