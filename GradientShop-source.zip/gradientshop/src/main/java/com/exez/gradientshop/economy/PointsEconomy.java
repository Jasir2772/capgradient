package com.exez.gradientshop.economy;

import org.black_ixx.playerpoints.PlayerPoints;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;

import java.util.UUID;

public class PointsEconomy {

    private final PlayerPointsAPI api;

    public PointsEconomy() {
        PlayerPoints plugin = (PlayerPoints) Bukkit.getPluginManager().getPlugin("PlayerPoints");
        if (plugin == null) {
            throw new IllegalStateException("PlayerPoints plagini topilmadi! Uni avval o'rnating.");
        }
        this.api = plugin.getAPI();
    }

    public long getBalance(UUID uuid) {
        return api.look(uuid);
    }

    public boolean has(UUID uuid, long amount) {
        return getBalance(uuid) >= amount;
    }

    public boolean take(UUID uuid, long amount) {
        if (!has(uuid, amount)) return false;
        return api.take(uuid, (int) amount);
    }

    public boolean give(UUID uuid, long amount) {
        return api.give(uuid, (int) amount);
    }
}
