package com.exez.gradientshop.listener;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.GradientUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class JoinListener implements Listener {

    private final GradientShopPlugin plugin;

    public JoinListener(GradientShopPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        PlayerData data = plugin.getDataManager().get(event.getPlayer().getUniqueId());
        applyNameColor(event.getPlayer(), data);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getDataManager().unload(event.getPlayer().getUniqueId());
    }

    public void applyNameColor(org.bukkit.entity.Player player, PlayerData data) {
        if (data.isNameColorEnabled() && data.getActiveNameColor() != null) {
            ShopEntry entry = plugin.getShopConfig().getNameColors().get(data.getActiveNameColor());
            if (entry != null) {
                String colored = GradientUtil.single(player.getName(), entry.from);
                player.setPlayerListName(colored);
                player.setDisplayName(colored);
                return;
            }
        }
        player.setPlayerListName(player.getName());
        player.setDisplayName(player.getName());
    }
}
