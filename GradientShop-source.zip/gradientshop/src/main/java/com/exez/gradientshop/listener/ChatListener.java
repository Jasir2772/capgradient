package com.exez.gradientshop.listener;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.FontUtil;
import com.exez.gradientshop.util.GradientUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatListener implements Listener {

    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

    private final GradientShopPlugin plugin;
    private final Random random = new Random();

    public ChatListener(GradientShopPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());

        String message = event.getMessage();

        // Font effekti (unicode almashtirish)
        if (data.isFontEnabled()) {
            ShopEntry fontEntry = plugin.getShopConfig().getFonts().get(data.getActiveFont());
            if (fontEntry != null) {
                message = FontUtil.apply(message, fontEntry.style);
            }
        }

        // Gradient effekti
        if (data.isGradientEnabled()) {
            String gradientId = data.getActiveGradient();
            if (data.isRandomEnabled() && !data.getOwnedGradients().isEmpty()) {
                List<String> owned = new ArrayList<>(data.getOwnedGradients());
                gradientId = owned.get(random.nextInt(owned.size()));
            }
            if (gradientId != null) {
                ShopEntry gradEntry = plugin.getShopConfig().getGradients().get(gradientId);
                if (gradEntry != null) {
                    message = GradientUtil.applyGradient(message, gradEntry.from, gradEntry.to);
                }
            }
        }

        // Nik rangi
        String displayName = player.getName();
        if (data.isNameColorEnabled() && data.getActiveNameColor() != null) {
            ShopEntry colorEntry = plugin.getShopConfig().getNameColors().get(data.getActiveNameColor());
            if (colorEntry != null) {
                displayName = GradientUtil.single(player.getName(), colorEntry.from);
            }
        }

        event.setCancelled(true);

        // Boshqa plaginlar (rank/prefix) o'rnatgan formatni saqlab qolamiz.
        // Odatiy Bukkit formati: "%1$s: %2$s" (%1$s = ism, %2$s = xabar).
        // Rank/prefix plaginlari (masalan LuckPerms) odatda shu formatni
        // "[VIP] %1$s: %2$s" kabi qayta yozadi - biz uni buzmaymiz.
        String rawFormat = translateColors(event.getFormat());
        String finalFormat;
        try {
            finalFormat = String.format(rawFormat, displayName, message);
        } catch (Exception e) {
            // format satrida kutilmagan belgi bo'lsa, oddiy formatga qaytamiz
            plugin.getLogger().warning("Chat formatini o'qishda xato, standart formatga o'tildi: " + e.getMessage());
            finalFormat = ChatColor.WHITE + displayName + ChatColor.GRAY + ": " + message;
        }

        for (Player online : Bukkit.getOnlinePlayers()) {
            online.sendMessage(finalFormat);
        }
        Bukkit.getConsoleSender().sendMessage(ChatColor.stripColor(finalFormat));
    }

    /**
     * Boshqa plaginning format satrida "&#RRGGBB" ko'rinishidagi xom hex teglar
     * qolib ketgan bo'lishi mumkin (chunki ular odatda vanilla chat jarayoni
     * yoki boshqa listener orqali tarjima qilinadi, biz esa eventni o'zimiz
     * bekor qilib yuboramiz). Shuning uchun o'zimiz tarjima qilamiz:
     * avval hex ("&#RRGGBB" -> haqiqiy rang), keyin oddiy "&"-kodlar.
     */
    private String translateColors(String text) {
        if (text == null) return "%1$s: %2$s";
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuilder buffer = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            String replacement = net.md_5.bungee.api.ChatColor.of("#" + hex).toString();
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(buffer);
        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }
}
