package com.exez.gradientshop.listener;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.FontUtil;
import com.exez.gradientshop.util.GradientUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ChatListener implements Listener {

    private final GradientShopPlugin plugin;
    private final Random random = new Random();

    public ChatListener(GradientShopPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());

        String message = event.getMessage();

        // Font effekti (unicode almashtirish)
        if (data.isFontEnabled()) {
            ShopEntry fontEntry = plugin.getShopConfig().getFonts().get(data.getActiveFont());
            if (fontEntry != null) {
                message = FontUtil.apply(message, fontEntry.style);
            }
        }

        // Gradient effekti
        if (data.isGradientEnabled()) {
            String gradientId = data.getActiveGradient();
            if (data.isRandomEnabled() && !data.getOwnedGradients().isEmpty()) {
                List<String> owned = new ArrayList<>(data.getOwnedGradients());
                gradientId = owned.get(random.nextInt(owned.size()));
            }
            if (gradientId != null) {
                ShopEntry gradEntry = plugin.getShopConfig().getGradients().get(gradientId);
                if (gradEntry != null) {
                    message = GradientUtil.applyGradient(message, gradEntry.from, gradEntry.to);
                }
            }
        }

        // Nik rangi
        String displayName = player.getName();
        if (data.isNameColorEnabled() && data.getActiveNameColor() != null) {
            ShopEntry colorEntry = plugin.getShopConfig().getNameColors().get(data.getActiveNameColor());
            if (colorEntry != null) {
                displayName = GradientUtil.single(player.getName(), colorEntry.from);
            }
        }

        event.setCancelled(true);
        String finalFormat = ChatColor.WHITE + displayName + ChatColor.GRAY + ": " + message;
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.sendMessage(finalFormat);
        }
        Bukkit.getConsoleSender().sendMessage(ChatColor.stripColor(finalFormat));
    }
}
