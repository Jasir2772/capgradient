package com.exez.gradientshop.data;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

public class ShopConfig {

    private final Map<String, ShopEntry> gradients = new LinkedHashMap<>();
    private final Map<String, ShopEntry> fonts = new LinkedHashMap<>();
    private final Map<String, ShopEntry> nameColors = new LinkedHashMap<>();

    public ShopConfig(JavaPlugin plugin) {
        reload(plugin);
    }

    public void reload(JavaPlugin plugin) {
        gradients.clear();
        fonts.clear();
        nameColors.clear();

        ConfigurationSection g = plugin.getConfig().getConfigurationSection("gradients");
        if (g != null) {
            for (String id : g.getKeys(false)) {
                ConfigurationSection s = g.getConfigurationSection(id);
                gradients.put(id, new ShopEntry(id, s.getString("name"), s.getString("from"),
                        s.getString("to"), null, s.getLong("price")));
            }
        }

        ConfigurationSection f = plugin.getConfig().getConfigurationSection("fonts");
        if (f != null) {
            for (String id : f.getKeys(false)) {
                ConfigurationSection s = f.getConfigurationSection(id);
                fonts.put(id, new ShopEntry(id, s.getString("name"), null, null,
                        s.getString("style"), s.getLong("price")));
            }
        }

        ConfigurationSection n = plugin.getConfig().getConfigurationSection("namecolors");
        if (n != null) {
            for (String id : n.getKeys(false)) {
                ConfigurationSection s = n.getConfigurationSection(id);
                nameColors.put(id, new ShopEntry(id, s.getString("name"), s.getString("hex"),
                        null, null, s.getLong("price")));
            }
        }
    }

    public Map<String, ShopEntry> getGradients() { return gradients; }
    public Map<String, ShopEntry> getFonts() { return fonts; }
    public Map<String, ShopEntry> getNameColors() { return nameColors; }
}
