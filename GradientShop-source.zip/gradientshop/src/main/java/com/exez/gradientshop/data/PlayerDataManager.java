package com.exez.gradientshop.data;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public class PlayerDataManager {

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration yaml;
    private final Map<UUID, PlayerData> cache = new HashMap<>();

    public PlayerDataManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playerdata.yml");
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "playerdata.yml yaratilmadi", e);
            }
        }
        this.yaml = YamlConfiguration.loadConfiguration(file);
    }

    public PlayerData get(UUID uuid) {
        return cache.computeIfAbsent(uuid, this::load);
    }

    private PlayerData load(UUID uuid) {
        PlayerData data = new PlayerData(uuid);
        String path = uuid.toString();
        if (yaml.contains(path)) {
            data.setActiveGradient(yaml.getString(path + ".activeGradient", null));
            data.setActiveFont(yaml.getString(path + ".activeFont", "default"));
            data.setActiveNameColor(yaml.getString(path + ".activeNameColor", null));
            data.setGradientEnabled(yaml.getBoolean(path + ".gradientEnabled", false));
            data.setFontEnabled(yaml.getBoolean(path + ".fontEnabled", false));
            data.setRandomEnabled(yaml.getBoolean(path + ".randomEnabled", false));
            data.setNameColorEnabled(yaml.getBoolean(path + ".nameColorEnabled", false));
            data.getOwnedGradients().addAll(yaml.getStringList(path + ".ownedGradients"));
            data.getOwnedFonts().addAll(yaml.getStringList(path + ".ownedFonts"));
            data.getOwnedNameColors().addAll(yaml.getStringList(path + ".ownedNameColors"));
            data.setFavoriteGradient(yaml.getString(path + ".favoriteGradient", null));
            data.setFavoriteFont(yaml.getString(path + ".favoriteFont", null));
            data.setFavoriteNameColor(yaml.getString(path + ".favoriteNameColor", null));
            data.addSpentTokens(yaml.getLong(path + ".spentTokens", 0));
        }
        return data;
    }

    public void save(PlayerData data) {
        String path = data.getUuid().toString();
        yaml.set(path + ".activeGradient", data.getActiveGradient());
        yaml.set(path + ".activeFont", data.getActiveFont());
        yaml.set(path + ".activeNameColor", data.getActiveNameColor());
        yaml.set(path + ".gradientEnabled", data.isGradientEnabled());
        yaml.set(path + ".fontEnabled", data.isFontEnabled());
        yaml.set(path + ".randomEnabled", data.isRandomEnabled());
        yaml.set(path + ".nameColorEnabled", data.isNameColorEnabled());
        yaml.set(path + ".ownedGradients", new java.util.ArrayList<>(data.getOwnedGradients()));
        yaml.set(path + ".ownedFonts", new java.util.ArrayList<>(data.getOwnedFonts()));
        yaml.set(path + ".ownedNameColors", new java.util.ArrayList<>(data.getOwnedNameColors()));
        yaml.set(path + ".favoriteGradient", data.getFavoriteGradient());
        yaml.set(path + ".favoriteFont", data.getFavoriteFont());
        yaml.set(path + ".favoriteNameColor", data.getFavoriteNameColor());
        yaml.set(path + ".spentTokens", data.getSpentTokens());
        saveFile();
    }

    public void saveAll() {
        for (PlayerData data : cache.values()) {
            save(data);
        }
    }

    public void unload(UUID uuid) {
        PlayerData data = cache.remove(uuid);
        if (data != null) save(data);
    }

    private void saveFile() {
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "playerdata.yml saqlanmadi", e);
        }
    }

    /** Top menyusi uchun: barcha keshdagi + diskdagi o'yinchilar bo'yicha spentTokens ro'yxati. */
    public Map<UUID, Long> getAllSpentTokens() {
        Map<UUID, Long> result = new HashMap<>();
        for (String key : yaml.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                long spent = yaml.getLong(key + ".spentTokens", 0);
                result.put(id, spent);
            } catch (IllegalArgumentException ignored) {}
        }
        for (PlayerData data : cache.values()) {
            result.put(data.getUuid(), data.getSpentTokens());
        }
        return result;
    }
}
