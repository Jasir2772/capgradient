package com.exez.gradientshop.data;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerData {

    private final UUID uuid;
    private String activeGradient = null;
    private String activeFont = "default";
    private String activeNameColor = null;

    private boolean gradientEnabled = false;
    private boolean fontEnabled = false;
    private boolean randomEnabled = false;
    private boolean nameColorEnabled = false;

    private final Set<String> ownedGradients = new HashSet<>();
    private final Set<String> ownedFonts = new HashSet<>(Set.of("default"));
    private final Set<String> ownedNameColors = new HashSet<>();

    private String favoriteGradient = null;
    private String favoriteFont = null;
    private String favoriteNameColor = null;

    private long spentTokens = 0;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() { return uuid; }

    public String getActiveGradient() { return activeGradient; }
    public void setActiveGradient(String g) { this.activeGradient = g; }

    public String getActiveFont() { return activeFont; }
    public void setActiveFont(String f) { this.activeFont = f; }

    public String getActiveNameColor() { return activeNameColor; }
    public void setActiveNameColor(String c) { this.activeNameColor = c; }

    public boolean isGradientEnabled() { return gradientEnabled; }
    public void setGradientEnabled(boolean b) { this.gradientEnabled = b; }

    public boolean isFontEnabled() { return fontEnabled; }
    public void setFontEnabled(boolean b) { this.fontEnabled = b; }

    public boolean isRandomEnabled() { return randomEnabled; }
    public void setRandomEnabled(boolean b) { this.randomEnabled = b; }

    public boolean isNameColorEnabled() { return nameColorEnabled; }
    public void setNameColorEnabled(boolean b) { this.nameColorEnabled = b; }

    public Set<String> getOwnedGradients() { return ownedGradients; }
    public Set<String> getOwnedFonts() { return ownedFonts; }
    public Set<String> getOwnedNameColors() { return ownedNameColors; }

    public String getFavoriteGradient() { return favoriteGradient; }
    public void setFavoriteGradient(String f) { this.favoriteGradient = f; }

    public String getFavoriteFont() { return favoriteFont; }
    public void setFavoriteFont(String f) { this.favoriteFont = f; }

    public String getFavoriteNameColor() { return favoriteNameColor; }
    public void setFavoriteNameColor(String f) { this.favoriteNameColor = f; }

    public long getSpentTokens() { return spentTokens; }
    public void addSpentTokens(long amount) { this.spentTokens += amount; }

    public void resetToDefault() {
        gradientEnabled = false;
        fontEnabled = false;
        randomEnabled = false;
        nameColorEnabled = false;
    }
}
