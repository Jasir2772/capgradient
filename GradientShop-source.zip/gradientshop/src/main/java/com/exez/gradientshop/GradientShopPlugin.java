package com.exez.gradientshop;

import com.exez.gradientshop.command.ShopCommand;
import com.exez.gradientshop.data.PlayerDataManager;
import com.exez.gradientshop.data.ShopConfig;
import com.exez.gradientshop.economy.PointsEconomy;
import com.exez.gradientshop.listener.ChatListener;
import com.exez.gradientshop.listener.InventoryListener;
import com.exez.gradientshop.listener.JoinListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class GradientShopPlugin extends JavaPlugin {

    private PlayerDataManager dataManager;
    private ShopConfig shopConfig;
    private PointsEconomy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        if (Bukkit.getPluginManager().getPlugin("PlayerPoints") == null) {
            getLogger().severe("PlayerPoints topilmadi! Plagin o'chirilmoqda.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        this.dataManager = new PlayerDataManager(this);
        this.shopConfig = new ShopConfig(this);
        this.economy = new PointsEconomy();

        Bukkit.getPluginManager().registerEvents(new InventoryListener(), this);
        Bukkit.getPluginManager().registerEvents(new ChatListener(this), this);
        Bukkit.getPluginManager().registerEvents(new JoinListener(this), this);

        ShopCommand command = new ShopCommand(this);
        getCommand("gshop").setExecutor(command);
        getCommand("gradient").setExecutor(command);
        getCommand("gsreload").setExecutor(command);

        getLogger().info("GradientShop yoqildi. Gradient: " + shopConfig.getGradients().size()
                + " | Font: " + shopConfig.getFonts().size()
                + " | NameColor: " + shopConfig.getNameColors().size());
    }

    @Override
    public void onDisable() {
        if (dataManager != null) {
            dataManager.saveAll();
        }
    }

    public void reloadShopConfig() {
        reloadConfig();
        shopConfig.reload(this);
    }

    public PlayerDataManager getDataManager() {
        return dataManager;
    }

    public ShopConfig getShopConfig() {
        return shopConfig;
    }

    public PointsEconomy getEconomy() {
        return economy;
    }
}
