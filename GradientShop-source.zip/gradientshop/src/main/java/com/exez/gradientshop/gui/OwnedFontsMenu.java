package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.FontUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class OwnedFontsMenu extends AbstractMenu {

    private static final int[] SLOTS = {11, 13, 15, 20, 22, 24, 29, 31, 33};
    private final int page;
    private List<String> owned;

    public OwnedFontsMenu(GradientShopPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = page;
    }

    @Override
    public void build() {
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        owned = new ArrayList<>(data.getOwnedFonts());

        String title = color(plugin.getConfig().getString("gui-titles.owned-fonts").replace("%page%", String.valueOf(page)));
        inventory = Bukkit.createInventory(this, 54, title);
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        for (int i = 0; i < owned.size() && i < SLOTS.length; i++) {
            String id = owned.get(i);
            ShopEntry entry = plugin.getShopConfig().getFonts().get(id);
            boolean selected = id.equals(data.getActiveFont());

            List<String> lore = new ArrayList<>();
            lore.add("&bFAOL FONT");
            lore.add("&7Holat: " + (selected ? "&aFAOLLASHTIRILGAN" : "&7Faol emas"));
            lore.add("&fNIK: &f" + FontUtil.apply(player.getName(), entry.style));
            lore.add("&fMATN: &f" + FontUtil.apply(
                    plugin.getConfig().getString("preview.text-sample"), entry.style));
            lore.add("");
            lore.add("&aBosib faollashtirasiz");

            inventory.setItem(SLOTS[i], item(Material.BOOK, entry.name, lore));
        }

        inventory.setItem(45, item(Material.RED_DYE, "&cORQAGA", null));
        inventory.setItem(49, item(Material.CHEST, "&6BOSH MENYU", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == 45 || slot == 49) { openMenu(new MainMenu(plugin, player)); return; }

        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] == slot && i < owned.size()) {
                String id = owned.get(i);
                PlayerData data = plugin.getDataManager().get(player.getUniqueId());
                data.setActiveFont(id);
                data.setFavoriteFont(id);
                data.setFontEnabled(!id.equals("default"));
                plugin.getDataManager().save(data);
                openMenu(new OwnedFontsMenu(plugin, player, page));
                return;
            }
        }
    }
}
