package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.FontUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class FontShopMenu extends AbstractMenu {

    private static final int[] SLOTS = {11, 13, 15, 20, 22, 24, 29, 31, 33};
    private final int page;
    private List<String> ids;

    public FontShopMenu(GradientShopPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = page;
    }

    @Override
    public void build() {
        ids = new ArrayList<>(plugin.getShopConfig().getFonts().keySet());
        String title = color(plugin.getConfig().getString("gui-titles.fonts").replace("%page%", String.valueOf(page)));
        inventory = Bukkit.createInventory(this, 54, title);
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        PlayerData data = plugin.getDataManager().get(player.getUniqueId());

        for (int i = 0; i < ids.size() && i < SLOTS.length; i++) {
            String id = ids.get(i);
            ShopEntry entry = plugin.getShopConfig().getFonts().get(id);
            boolean owned = data.getOwnedFonts().contains(id);
            boolean selected = id.equals(data.getActiveFont());

            String status = selected ? "&aTANLANGAN" : (owned ? "&2SOTIB OLINGAN" : "&cSOTIB OLINMAGAN");
            String nickPreview = "&f" + FontUtil.apply(player.getName(), entry.style);
            String textPreview = "&f" + FontUtil.apply(
                    plugin.getConfig().getString("preview.text-sample"), entry.style);

            List<String> lore = new ArrayList<>();
            lore.add("&7Narx: &e" + entry.price + " token");
            lore.add("&7Holat: " + status);
            lore.add(nickPreview);
            lore.add(textPreview);
            lore.add("");
            lore.add(owned ? "&a▶ Bosib tanlang" : "&a▶ Bosib sotib oling");

            inventory.setItem(SLOTS[i], item(Material.LIGHT_BLUE_DYE, entry.name, lore));
        }

        int backSlot = navSlot("menus.font-shop.back", 45);
        int homeSlot = navSlot("menus.font-shop.home", 49);
        int ownedSlot = navSlot("menus.font-shop.owned", 53);
        inventory.setItem(backSlot, navItem("menus.font-shop.back", Material.RED_DYE, "&cORQAGA", null));
        inventory.setItem(homeSlot, navItem("menus.font-shop.home", Material.CHEST, "&6BOSH MENYU", null));
        inventory.setItem(ownedSlot, navItem("menus.font-shop.owned", Material.PINK_DYE, "&dOLINGAN FONTLAR", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == navSlot("menus.font-shop.back", 45) || slot == navSlot("menus.font-shop.home", 49)) { openMenu(new MainMenu(plugin, player)); return; }
        if (slot == navSlot("menus.font-shop.owned", 53)) { openMenu(new OwnedFontsMenu(plugin, player, 1)); return; }

        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] == slot && i < ids.size()) {
                handlePurchaseOrSelect(ids.get(i));
                return;
            }
        }
    }

    private void handlePurchaseOrSelect(String id) {
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        ShopEntry entry = plugin.getShopConfig().getFonts().get(id);

        if (data.getOwnedFonts().contains(id)) {
            data.setActiveFont(id);
            data.setFontEnabled(!id.equals("default"));
            player.sendMessage(color(plugin.getConfig().getString("messages.activated")
                    .replace("%name%", entry.name)));
            playConfigSound("sounds.select");
        } else {
            if (!plugin.getEconomy().has(player.getUniqueId(), entry.price)) {
                player.sendMessage(color(plugin.getConfig().getString("messages.not-enough-tokens")
                        .replace("%price%", String.valueOf(entry.price))));
                playConfigSound("sounds.error");
                return;
            }
            plugin.getEconomy().take(player.getUniqueId(), entry.price);
            data.getOwnedFonts().add(id);
            data.addSpentTokens(entry.price);
            data.setActiveFont(id);
            data.setFontEnabled(true);
            player.sendMessage(color(plugin.getConfig().getString("messages.purchased")
                    .replace("%name%", entry.name)));
            playConfigSound("sounds.purchase");
        }
        plugin.getDataManager().save(data);
        openMenu(new FontShopMenu(plugin, player, page));
    }
}
