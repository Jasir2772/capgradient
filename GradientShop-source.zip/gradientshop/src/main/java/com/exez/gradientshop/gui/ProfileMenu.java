package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class ProfileMenu extends AbstractMenu {

    public ProfileMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        inventory = Bukkit.createInventory(this, 27, color(plugin.getConfig().getString("gui-titles.profile")));
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        long balance = plugin.getEconomy().getBalance(player.getUniqueId());

        String activeGradientName = data.getActiveGradient() == null ? "Yoqilmagan" :
                nameOf(plugin.getShopConfig().getGradients().get(data.getActiveGradient()));
        String activeFontName = nameOf(plugin.getShopConfig().getFonts().get(data.getActiveFont()));
        String activeNameColorName = data.getActiveNameColor() == null ? "Yoqilmagan" :
                nameOf(plugin.getShopConfig().getNameColors().get(data.getActiveNameColor()));

        List<String> lore = new ArrayList<>();
        lore.add("&fUUID: &7" + player.getUniqueId());
        lore.add("&fActive gradient: &e" + activeGradientName);
        lore.add("&fActive font: &e" + activeFontName);
        lore.add("&fGradient enabled: " + bool(data.isGradientEnabled()));
        lore.add("&fFont enabled: " + bool(data.isFontEnabled()));
        lore.add("&fRandom mode: " + bool(data.isRandomEnabled()));
        lore.add("&fOwned gradients: &a" + data.getOwnedGradients().size());
        lore.add("&fOwned fonts: &a" + data.getOwnedFonts().size());
        lore.add("&f" + player.getName() + " color: &e" + activeNameColorName);
        lore.add("&fOwned name colors: &a" + data.getOwnedNameColors().size());
        lore.add("&fFavorites: &a" + countFavorites(data));
        lore.add("&fSpent: &6" + data.getSpentTokens() + " Token");
        lore.add("&fProvider: &7PlayerPoints");
        lore.add("&fBalance: &6" + balance + " Token");

        ItemStack head = item(Material.PLAYER_HEAD, "&e" + player.getName(), lore);
        if (head.getItemMeta() instanceof SkullMeta meta) {
            meta.setOwningPlayer(player);
            meta.setDisplayName(color("&e" + player.getName()));
            meta.setLore(lore.stream().map(this::color).toList());
            head.setItemMeta(meta);
        }
        inventory.setItem(13, head);

        List<String> gradLore = List.of("&7" + (data.getActiveGradient() == null ? "Yoqilmagan" : activeGradientName));
        inventory.setItem(11, item(Material.ORANGE_DYE, "&6FAOL GRADIENT", gradLore));

        List<String> fontLore = List.of("&7" + activeFontName.toUpperCase());
        inventory.setItem(15, item(Material.BLUE_DYE, "&9FAOL FONT", fontLore));

        inventory.setItem(18, item(Material.RED_DYE, "&cOrqaga", null));
        inventory.setItem(26, item(Material.CHEST, "&6Bosh menyu", null));
    }

    private int countFavorites(PlayerData data) {
        int c = 0;
        if (data.getFavoriteGradient() != null) c++;
        if (data.getFavoriteFont() != null) c++;
        if (data.getFavoriteNameColor() != null) c++;
        return c;
    }

    private String nameOf(ShopEntry entry) {
        return entry == null ? "DEFAULT" : entry.name;
    }

    private String bool(boolean b) {
        return b ? "&atrue" : "&cfalse";
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == 18 || slot == 26) {
            openMenu(new MainMenu(plugin, player));
        }
    }
}
