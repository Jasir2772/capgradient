package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class ProfileMenu extends AbstractMenu {

    public ProfileMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        inventory = Bukkit.createInventory(this, 27, color(plugin.getConfig().getString("gui-titles.profile")));
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        long balance = plugin.getEconomy().getBalance(player.getUniqueId());

        String activeGradientName = data.getActiveGradient() == null ? "Yoqilmagan" :
                nameOf(plugin.getShopConfig().getGradients().get(data.getActiveGradient()));
        String activeFontName = nameOf(plugin.getShopConfig().getFonts().get(data.getActiveFont()));
        String activeNameColorName = data.getActiveNameColor() == null ? "Yoqilmagan" :
                nameOf(plugin.getShopConfig().getNameColors().get(data.getActiveNameColor()));

        List<String> lore = new ArrayList<>();
        lore.add("&fUUID: &7" + player.getUniqueId());
        lore.add("&fActive gradient: &e" + activeGradientName);
        lore.add("&fActive font: &e" + activeFontName);
        lore.add("&fGradient enabled: " + bool(data.isGradientEnabled()));
        lore.add("&fFont enabled: " + bool(data.isFontEnabled()));
        lore.add("&fRandom mode: " + bool(data.isRandomEnabled()));
        lore.add("&fOwned gradients: &a" + data.getOwnedGradients().size());
        lore.add("&fOwned fonts: &a" + data.getOwnedFonts().size());
        lore.add("&f" + player.getName() + " color: &e" + activeNameColorName);
        lore.add("&fOwned name colors: &a" + data.getOwnedNameColors().size());
        lore.add("&fFavorites: &a" + countFavorites(data));
        lore.add("&fSpent: &6" + data.getSpentTokens() + " Token");
        lore.add("&fProvider: &7PlayerPoints");
        lore.add("&fBalance: &6" + balance + " Token");

        Material headMat = Material.MAGENTA_DYE;
        String headMatStr = plugin.getConfig().getString("menus.profile.head-material");
        if (headMatStr != null) {
            try { headMat = Material.valueOf(headMatStr.toUpperCase()); } catch (IllegalArgumentException ignored) {}
        }
        ItemStack head = item(headMat, "&e" + player.getName(), lore);
        inventory.setItem(13, head);

        List<String> gradLore = List.of("&7" + (data.getActiveGradient() == null ? "Yoqilmagan" : activeGradientName));
        int gradSlot = navSlot("menus.profile.active-gradient", 11);
        inventory.setItem(gradSlot, navItem("menus.profile.active-gradient", Material.ORANGE_DYE, "&6FAOL GRADIENT", gradLore));

        List<String> fontLore = List.of("&7" + activeFontName.toUpperCase());
        int fontSlot = navSlot("menus.profile.active-font", 15);
        inventory.setItem(fontSlot, navItem("menus.profile.active-font", Material.BLUE_DYE, "&9FAOL FONT", fontLore));

        int backSlot = navSlot("menus.profile.back", 18);
        int homeSlot = navSlot("menus.profile.home", 26);
        inventory.setItem(backSlot, navItem("menus.profile.back", Material.RED_DYE, "&cOrqaga", null));
        inventory.setItem(homeSlot, navItem("menus.profile.home", Material.CHEST, "&6Bosh menyu", null));
    }

    private int countFavorites(PlayerData data) {
        int c = 0;
        if (data.getFavoriteGradient() != null) c++;
        if (data.getFavoriteFont() != null) c++;
        if (data.getFavoriteNameColor() != null) c++;
        return c;
    }

    private String nameOf(ShopEntry entry) {
        return entry == null ? "DEFAULT" : entry.name;
    }

    private String bool(boolean b) {
        return b ? "&atrue" : "&cfalse";
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == navSlot("menus.profile.back", 18) || slot == navSlot("menus.profile.home", 26)) {
            openMenu(new MainMenu(plugin, player));
        }
    }
}
