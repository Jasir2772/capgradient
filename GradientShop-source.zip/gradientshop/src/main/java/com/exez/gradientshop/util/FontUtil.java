package com.exez.gradientshop.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Resurs-paketsiz font effekti: harflarni unicode variantlariga almashtiradi.
 */
public class FontUtil {

    private static final Map<Character, Character> SMALL_CAPS = new HashMap<>();

    static {
        String normal = "abcdefghijklmnopqrstuvwxyz";
        String small = "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ";
        for (int i = 0; i < normal.length(); i++) {
            SMALL_CAPS.put(normal.charAt(i), small.charAt(i));
        }
    }

    public static String apply(String text, String style) {
        if (text == null) return text;
        switch (style) {
            case "SMALL_CAPS":
                return applySmallCaps(text);
            case "BOLD_ITALIC":
                return applyBoldItalic(text);
            case "BOLD":
                return applyOffset(text, 0x1D400, 0x1D41A, 0x1D7CE);
            case "ITALIC":
                return applyItalic(text);
            case "MONOSPACE":
                return applyOffset(text, 0x1D670, 0x1D68A, 0x1D7F6);
            case "DOUBLE_STRUCK":
                return applyOffset(text, 0x1D538, 0x1D552, 0x1D7D8);
            case "CIRCLED":
                return applyCircled(text);
            case "FULLWIDTH":
                return applyOffset(text, 0xFF21, 0xFF41, 0xFF10);
            case "STRIKETHROUGH":
                return applyCombining(text, '\u0336');
            case "UNDERLINE":
                return applyCombining(text, '\u0332');
            default:
                return text;
        }
    }

    /** A-Z / a-z / 0-9 uchun uzunroq unicode blokka offset qilib ko'chiradi. */
    private static String applyOffset(String text, int upperBase, int lowerBase, int digitBase) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                sb.appendCodePoint(upperBase + (c - 'A'));
            } else if (c >= 'a' && c <= 'z') {
                sb.appendCodePoint(lowerBase + (c - 'a'));
            } else if (c >= '0' && c <= '9' && digitBase > 0) {
                sb.appendCodePoint(digitBase + (c - '0'));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    // Mathematical Italic: A-Z -> U+1D434.., a-z -> U+1D44E.. ('h' uchun alohida istisno U+210E)
    private static String applyItalic(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c == 'h') {
                sb.appendCodePoint(0x210E);
            } else if (c >= 'A' && c <= 'Z') {
                sb.appendCodePoint(0x1D434 + (c - 'A'));
            } else if (c >= 'a' && c <= 'z') {
                sb.appendCodePoint(0x1D44E + (c - 'a'));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    // Ⓒⓘⓡⓒⓛⓔⓓ: A-Z -> U+24B6.., a-z -> U+24D0.., 0 -> U+24EA, 1-9 -> U+2460..
    private static String applyCircled(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                sb.appendCodePoint(0x24B6 + (c - 'A'));
            } else if (c >= 'a' && c <= 'z') {
                sb.appendCodePoint(0x24D0 + (c - 'a'));
            } else if (c == '0') {
                sb.appendCodePoint(0x24EA);
            } else if (c >= '1' && c <= '9') {
                sb.appendCodePoint(0x2460 + (c - '1'));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    // S̶t̶r̶i̶k̶e̶t̶h̶r̶o̶u̶g̶h̶ / U̲n̲d̲e̲r̲l̲i̲n̲e̲: har bir belgidan keyin combining unicode belgi qo'shiladi.
    private static String applyCombining(String text, char combining) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            sb.append(c);
            if (!Character.isWhitespace(c)) {
                sb.append(combining);
            }
        }
        return sb.toString();
    }

    private static String applySmallCaps(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            char lower = Character.toLowerCase(c);
            sb.append(SMALL_CAPS.getOrDefault(lower, c));
        }
        return sb.toString();
    }

    // Mathematical Bold Italic: A-Z -> U+1D468.., a-z -> U+1D482.., 0-9 oddiy qoladi
    private static String applyBoldItalic(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                int cp = 0x1D468 + (c - 'A');
                sb.appendCodePoint(cp);
            } else if (c >= 'a' && c <= 'z') {
                int cp = 0x1D482 + (c - 'a');
                sb.appendCodePoint(cp);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
