package com.exez.gradientshop.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Resurs-paketsiz font effekti: harflarni unicode variantlariga almashtiradi.
 */
public class FontUtil {

    private static final Map<Character, Character> SMALL_CAPS = new HashMap<>();

    static {
        String normal = "abcdefghijklmnopqrstuvwxyz";
        String small = "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ";
        for (int i = 0; i < normal.length(); i++) {
            SMALL_CAPS.put(normal.charAt(i), small.charAt(i));
        }
    }

    public static String apply(String text, String style) {
        if (text == null) return text;
        switch (style) {
            case "SMALL_CAPS":
                return applySmallCaps(text);
            case "BOLD_ITALIC":
                return applyBoldItalic(text);
            default:
                return text;
        }
    }

    private static String applySmallCaps(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            char lower = Character.toLowerCase(c);
            sb.append(SMALL_CAPS.getOrDefault(lower, c));
        }
        return sb.toString();
    }

    // Mathematical Bold Italic: A-Z -> U+1D468.., a-z -> U+1D482.., 0-9 oddiy qoladi
    private static String applyBoldItalic(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                int cp = 0x1D468 + (c - 'A');
                sb.appendCodePoint(cp);
            } else if (c >= 'a' && c <= 'z') {
                int cp = 0x1D482 + (c - 'a');
                sb.appendCodePoint(cp);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
