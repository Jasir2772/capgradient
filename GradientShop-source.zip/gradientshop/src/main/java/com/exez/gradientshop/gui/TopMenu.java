package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class TopMenu extends AbstractMenu {

    private static final int[] SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25
    };

    public TopMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        inventory = Bukkit.createInventory(this, 45, color(plugin.getConfig().getString("gui-titles.top")));
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        Map<UUID, Long> spentMap = plugin.getDataManager().getAllSpentTokens();
        List<Map.Entry<UUID, Long>> sorted = spentMap.entrySet().stream()
                .filter(e -> e.getValue() > 0)
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(SLOTS.length)
                .collect(Collectors.toList());

        int rank = 1;
        for (Map.Entry<UUID, Long> entry : sorted) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(entry.getKey());
            PlayerData data = plugin.getDataManager().get(entry.getKey());
            String name = op.getName() == null ? "Noma'lum" : op.getName();

            List<String> lore = new ArrayList<>();
            lore.add("&e#" + rank + " &f" + name);
            lore.add("&7Sarflagan: &6" + entry.getValue() + " Token");
            lore.add("&7Gradientlar: &d" + data.getOwnedGradients().size());
            lore.add("&7Fontlar: &b" + data.getOwnedFonts().size());

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            if (head.getItemMeta() instanceof SkullMeta meta) {
                meta.setOwningPlayer(op);
                meta.setDisplayName(color("&6#" + rank + " &f" + name));
                meta.setLore(lore.stream().map(this::color).toList());
                head.setItemMeta(meta);
            }
            inventory.setItem(SLOTS[rank - 1], head);
            rank++;
        }

        int backSlot = navSlot("menus.top.back", 40);
        inventory.setItem(backSlot, navItem("menus.top.back", Material.RED_DYE, "&cOrqaga", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == navSlot("menus.top.back", 40)) {
            openMenu(new MainMenu(plugin, player));
        }
    }
}
