package com.exez.gradientshop.command;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.gui.MainMenu;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShopCommand implements CommandExecutor {

    private final GradientShopPlugin plugin;

    public ShopCommand(GradientShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Bu buyruq faqat o'yinchilar uchun.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload") && sender.hasPermission("gradientshop.admin")) {
            plugin.reloadShopConfig();
            player.sendMessage(ChatColor.GREEN + "config.yml qayta yuklandi.");
            return true;
        }
        new MainMenu(plugin, player).open();
        return true;
    }
}
