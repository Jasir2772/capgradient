package com.exez.gradientshop.command;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.gui.GradientShopMenu;
import com.exez.gradientshop.gui.MainMenu;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Bitta klass barcha buyruqlarga (gshop, gradient, gsreload) xizmat qiladi.
 * Qaysi buyruq chaqirilganini command.getName() orqali aniqlaymiz.
 */
public class ShopCommand implements CommandExecutor {

    private final GradientShopPlugin plugin;

    public ShopCommand(GradientShopPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Bu buyruq faqat o'yinchilar uchun.");
            return true;
        }

        String cmdName = command.getName().toLowerCase();

        // /gsreload  YOKI  /gshop reload  (yoki /gradient reload)
        if (cmdName.equals("gsreload") || (args.length > 0 && args[0].equalsIgnoreCase("reload"))) {
            if (!sender.hasPermission("gradientshop.admin")) {
                player.sendMessage(ChatColor.RED + "Sizda ruxsat yo'q.");
                return true;
            }
            plugin.reloadShopConfig();
            player.sendMessage(ChatColor.GREEN + "config.yml qayta yuklandi.");
            return true;
        }

        // /gradient  yoki  /ngradient  -> to'g'ridan-to'g'ri Gradient do'konini ochadi
        if (cmdName.equals("gradient") || cmdName.equals("ngradient")) {
            new GradientShopMenu(plugin, player, 1).open();
            return true;
        }

        // /gshop -> Bosh menyu
        new MainMenu(plugin, player).open();
        return true;
    }
}
