package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.GradientUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class OwnedNameColorsMenu extends AbstractMenu {

    private static final int PAGE_SIZE = 21;
    private static final int[] SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private final int page;
    private List<String> owned;

    public OwnedNameColorsMenu(GradientShopPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = page;
    }

    @Override
    public void build() {
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        owned = new ArrayList<>(data.getOwnedNameColors());

        String title = color(plugin.getConfig().getString("gui-titles.owned-namecolors").replace("%page%", String.valueOf(page)));
        inventory = Bukkit.createInventory(this, 54, title);
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        int start = (page - 1) * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, owned.size());

        for (int i = start; i < end; i++) {
            String id = owned.get(i);
            ShopEntry entry = plugin.getShopConfig().getNameColors().get(id);
            boolean selected = id.equals(data.getActiveNameColor());
            boolean favorite = id.equals(data.getFavoriteNameColor());

            String colorName = GradientUtil.single(entry.name, entry.from) + (favorite ? " &e★" : "");
            List<String> lore = new ArrayList<>();
            lore.add("&7Holat: " + (selected ? "&aFAOLLASHTIRILGAN" : "&7Faol emas"));
            lore.add(GradientUtil.single(player.getName(), entry.from));
            lore.add("");
            lore.add("&aBosib faollashtiring / sevimli qiling");

            inventory.setItem(SLOTS[i - start], item(Material.PURPLE_DYE, colorName, lore));
        }

        inventory.setItem(45, item(Material.RED_DYE, "&cORQAGA", null));
        inventory.setItem(49, item(Material.CHEST, "&6BOSH MENYU", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == 45 || slot == 49) { openMenu(new MainMenu(plugin, player)); return; }

        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] == slot) {
                int index = (page - 1) * PAGE_SIZE + i;
                if (index >= owned.size()) return;
                String id = owned.get(index);
                PlayerData data = plugin.getDataManager().get(player.getUniqueId());
                data.setActiveNameColor(id);
                data.setFavoriteNameColor(id);
                data.setNameColorEnabled(true);
                plugin.getDataManager().save(data);
                openMenu(new OwnedNameColorsMenu(plugin, player, page));
                return;
            }
        }
    }
}
