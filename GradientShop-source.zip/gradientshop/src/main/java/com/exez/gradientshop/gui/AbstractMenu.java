package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public abstract class AbstractMenu implements InventoryHolder {

    protected final GradientShopPlugin plugin;
    protected final Player player;
    protected Inventory inventory;

    public AbstractMenu(GradientShopPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }

    public abstract void build();

    /** slot bosilganda chaqiriladi. */
    public abstract void onClick(int slot, ItemStack clicked);

    public void open() {
        build();
        player.openInventory(inventory);
        playConfigSound("sounds.menu-open");
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    protected String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    protected ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        if (lore != null) {
            meta.setLore(lore.stream().map(this::color).toList());
        }
        stack.setItemMeta(meta);
        return stack;
    }

    protected void fillBorder(Material mat) {
        ItemStack filler = item(mat, " ", null);
        int size = inventory.getSize();
        for (int i = 0; i < size; i++) {
            if (i < 9 || i >= size - 9 || i % 9 == 0 || i % 9 == 8) {
                inventory.setItem(i, filler);
            }
        }
    }

    protected void openMenu(AbstractMenu menu) {
        Bukkit.getScheduler().runTask(plugin, menu::open);
    }

    /**
     * config.yml'dagi "menus.<menu>.<key>" bo'limidan (slot, material, name, lore)
     * o'qib item yasaydi. Bo'lim topilmasa yoki noto'g'ri bo'lsa, fallback ishlatiladi.
     */
    protected ItemStack navItem(String path, Material fallbackMat, String fallbackName, List<String> fallbackLore) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection(path);
        if (sec == null) {
            return item(fallbackMat, fallbackName, fallbackLore);
        }
        Material mat = fallbackMat;
        String matStr = sec.getString("material");
        if (matStr != null) {
            try {
                mat = Material.valueOf(matStr.toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning(path + ".material noto'g'ri (" + matStr + "), fallback ishlatildi.");
            }
        }
        String name = sec.getString("name", fallbackName);
        List<String> lore = sec.contains("lore") ? sec.getStringList("lore") : fallbackLore;
        return item(mat, name, lore);
    }

    /** config.yml'dagi "menus.<menu>.<key>.slot" qiymatini o'qiydi, bo'lmasa fallback qaytadi. */
    protected int navSlot(String path, int fallbackSlot) {
        return plugin.getConfig().getInt(path + ".slot", fallbackSlot);
    }

    /**
     * ON/OFF holatga qarab material o'zgaradigan tugma (Sozlamalar menyusidagi kabi).
     * config.yml'dan "on-material", "off-material", "slot", "name" o'qiladi.
     */
    protected ItemStack navToggleItem(String path, boolean on, Material fallbackOn, Material fallbackOff, String fallbackLabel) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection(path);
        Material onMat = fallbackOn, offMat = fallbackOff;
        String label = fallbackLabel;
        if (sec != null) {
            try {
                if (sec.getString("on-material") != null) onMat = Material.valueOf(sec.getString("on-material").toUpperCase());
                if (sec.getString("off-material") != null) offMat = Material.valueOf(sec.getString("off-material").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning(path + ": noto'g'ri material, fallback ishlatildi.");
            }
            label = sec.getString("name", fallbackLabel);
        }
        String state = on ? "&aON" : "&cOFF";
        return item(on ? onMat : offMat, "&f" + label + ": " + state, List.of("&7Bosib holatni almashtiring."));
    }

    /** config.yml'dagi "sounds.<key>" (sound, volume, pitch) ni o'ynatadi. Xato bo'lsa jim o'tkazib yuboradi. */
    protected void playConfigSound(String path) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection(path);
        if (sec == null) return;
        String soundName = sec.getString("sound");
        if (soundName == null) return;
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase());
            float volume = (float) sec.getDouble("volume", 1.0);
            float pitch = (float) sec.getDouble("pitch", 1.0);
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning(path + ".sound noto'g'ri (" + soundName + ").");
        }
    }
}
