package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public abstract class AbstractMenu implements InventoryHolder {

    protected final GradientShopPlugin plugin;
    protected final Player player;
    protected Inventory inventory;

    public AbstractMenu(GradientShopPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }

    public abstract void build();

    /** slot bosilganda chaqiriladi. */
    public abstract void onClick(int slot, ItemStack clicked);

    public void open() {
        build();
        player.openInventory(inventory);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    protected String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    protected ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        if (lore != null) {
            meta.setLore(lore.stream().map(this::color).toList());
        }
        stack.setItemMeta(meta);
        return stack;
    }

    protected void fillBorder(Material mat) {
        ItemStack filler = item(mat, " ", null);
        int size = inventory.getSize();
        for (int i = 0; i < size; i++) {
            if (i < 9 || i >= size - 9 || i % 9 == 0 || i % 9 == 8) {
                inventory.setItem(i, filler);
            }
        }
    }

    protected void openMenu(AbstractMenu menu) {
        Bukkit.getScheduler().runTask(plugin, menu::open);
    }
}
