package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class MainMenu extends AbstractMenu {

    public MainMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        String title = color(plugin.getConfig().getString("gui-titles.main"));
        inventory = Bukkit.createInventory(this, 54, title);
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        // 1-qator: asosiy 4 ta bo'lim, orasida bo'sh joy bilan
        inventory.setItem(19, item(Material.ORANGE_DYE, "&6Gradient do'koni",
                List.of("&7Chat xabaringizni", "&7RGB gradient bilan bo'yang.")));
        inventory.setItem(21, item(Material.CORNFLOWER, "&9Font do'koni",
                List.of("&7Default, Bold Italic, Small Caps.")));
        inventory.setItem(23, item(Material.ALLIUM, "&dName color",
                List.of("&7Ismingizga alohida rang bering.")));
        inventory.setItem(25, item(Material.LIME_DYE, "&aSozlamalar",
                List.of("&7Gradient/font/random/name color'ni", "&7tez yoqing yoki o'chiring.")));

        // 2-qator: xuddi 1-qatordagi ustunlar ostida, tik tushib turadi
        inventory.setItem(37, item(Material.OXEYE_DAISY, "&dOlingan gradientlar",
                List.of("&7Sotib olgan gradientlaringiz.")));
        inventory.setItem(39, item(Material.CORNFLOWER, "&9Olingan fontlar",
                List.of("&7Sotib olgan fontlaringiz.")));
        inventory.setItem(41, item(Material.ALLIUM, "&dOlingan name colorlar",
                List.of("&7Sotib olgan name colorlaringiz.")));
        inventory.setItem(43, item(Material.GOLD_INGOT, "&6Top",
                List.of("&7Eng ko'p token sarflaganlar.")));

        // Eng pastda, markazda: Profil va Default holat
        inventory.setItem(48, item(Material.SUNFLOWER, "&eProfil",
                List.of("&7Statistikangiz va balansingiz.")));
        inventory.setItem(50, item(Material.AZURE_BLUET, "&fDefault holat",
                List.of("&7Hammasini bir bosishda", "&7standart holatga qaytaring.")));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        switch (slot) {
            case 19 -> openMenu(new GradientShopMenu(plugin, player, 1));
            case 21 -> openMenu(new FontShopMenu(plugin, player, 1));
            case 23 -> openMenu(new NameColorShopMenu(plugin, player, 1));
            case 25 -> openMenu(new SettingsMenu(plugin, player));
            case 37 -> openMenu(new OwnedGradientsMenu(plugin, player, 1));
            case 39 -> openMenu(new OwnedFontsMenu(plugin, player, 1));
            case 41 -> openMenu(new OwnedNameColorsMenu(plugin, player, 1));
            case 43 -> openMenu(new TopMenu(plugin, player));
            case 48 -> openMenu(new ProfileMenu(plugin, player));
            case 50 -> {
                var data = plugin.getDataManager().get(player.getUniqueId());
                data.resetToDefault();
                player.sendMessage(color(plugin.getConfig().getString("messages.reset")));
                openMenu(new MainMenu(plugin, player));
            }
        }
    }
}
