package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class MainMenu extends AbstractMenu {

    /** slot -> config-key (gradient-shop, font-shop, ...). config.yml'dan o'qiladi. */
    private final Map<Integer, String> slotKeys = new HashMap<>();

    public MainMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        String title = color(plugin.getConfig().getString("gui-titles.main"));
        int size = plugin.getConfig().getInt("main-menu.size", 54);
        inventory = Bukkit.createInventory(this, size, title);
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        slotKeys.clear();
        ConfigurationSection items = plugin.getConfig().getConfigurationSection("main-menu.items");
        if (items == null) {
            plugin.getLogger().warning("config.yml ichida 'main-menu.items' bo'limi topilmadi!");
            return;
        }

        for (String key : items.getKeys(false)) {
            ConfigurationSection sec = items.getConfigurationSection(key);
            if (sec == null) continue;

            int slot = sec.getInt("slot", -1);
            if (slot < 0 || slot >= size) {
                plugin.getLogger().warning("main-menu.items." + key + ": noto'g'ri slot (" + slot + ")");
                continue;
            }

            Material material;
            try {
                material = Material.valueOf(sec.getString("material", "STONE").toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().log(Level.WARNING, "main-menu.items." + key + ": noto'g'ri material, STONE ishlatildi.", e);
                material = Material.STONE;
            }

            String name = sec.getString("name", "&f" + key);
            List<String> lore = sec.getStringList("lore");

            inventory.setItem(slot, item(material, name, lore));
            slotKeys.put(slot, key);
        }
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        String key = slotKeys.get(slot);
        if (key == null) return;

        switch (key) {
            case "gradient-shop" -> openMenu(new GradientShopMenu(plugin, player, 1));
            case "font-shop" -> openMenu(new FontShopMenu(plugin, player, 1));
            case "namecolor-shop" -> openMenu(new NameColorShopMenu(plugin, player, 1));
            case "settings" -> openMenu(new SettingsMenu(plugin, player));
            case "owned-gradients" -> openMenu(new OwnedGradientsMenu(plugin, player, 1));
            case "owned-fonts" -> openMenu(new OwnedFontsMenu(plugin, player, 1));
            case "owned-namecolors" -> openMenu(new OwnedNameColorsMenu(plugin, player, 1));
            case "top" -> openMenu(new TopMenu(plugin, player));
            case "profile" -> openMenu(new ProfileMenu(plugin, player));
            case "reset" -> {
                var data = plugin.getDataManager().get(player.getUniqueId());
                data.resetToDefault();
                player.sendMessage(color(plugin.getConfig().getString("messages.reset")));
                openMenu(new MainMenu(plugin, player));
            }
            default -> plugin.getLogger().warning("main-menu.items: noma'lum key '" + key + "' (onClick'da ishlov berilmagan)");
        }
    }
}
