package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class MainMenu extends AbstractMenu {

    public MainMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        String title = color(plugin.getConfig().getString("gui-titles.main"));
        inventory = Bukkit.createInventory(this, 27, title);

        inventory.setItem(10, item(Material.ORANGE_DYE, "&6Gradient do'koni",
                List.of("&7Chat xabaringizni", "&7RGB gradient bilan bo'yang.")));
        inventory.setItem(11, item(Material.BOOK, "&9Font do'koni",
                List.of("&7Default, Bold Italic, Small Caps.")));
        inventory.setItem(12, item(Material.NAME_TAG, "&dName color",
                List.of("&7Ismingizga alohida rang bering.")));
        inventory.setItem(13, item(Material.LIME_DYE, "&aSozlamalar",
                List.of("&7Gradient/font/random/name color'ni", "&7tez yoqing yoki o'chiring.")));
        inventory.setItem(14, item(Material.CHEST, "&dOlingan narsalarim",
                List.of("&7Sotib olgan gradient, font", "&7va name colorlaringiz.")));
        inventory.setItem(15, item(Material.PLAYER_HEAD, "&eProfil",
                List.of("&7Statistikangiz va balansingiz.")));
        inventory.setItem(16, item(Material.GOLD_INGOT, "&6Top",
                List.of("&7Eng ko'p token sarflaganlar.")));
        inventory.setItem(22, item(Material.BARRIER, "&fDefault holat",
                List.of("&7Hammasini bir bosishda", "&7standart holatga qaytaring.")));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        switch (slot) {
            case 10 -> openMenu(new GradientShopMenu(plugin, player, 1));
            case 11 -> openMenu(new FontShopMenu(plugin, player, 1));
            case 12 -> openMenu(new NameColorShopMenu(plugin, player, 1));
            case 13 -> openMenu(new SettingsMenu(plugin, player));
            case 14 -> openMenu(new OwnedHubMenu(plugin, player));
            case 15 -> openMenu(new ProfileMenu(plugin, player));
            case 16 -> openMenu(new TopMenu(plugin, player));
            case 22 -> {
                var data = plugin.getDataManager().get(player.getUniqueId());
                data.resetToDefault();
                player.sendMessage(color(plugin.getConfig().getString("messages.reset")));
                openMenu(new MainMenu(plugin, player));
            }
        }
    }
}
