package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import com.exez.gradientshop.data.PlayerData;
import com.exez.gradientshop.data.ShopEntry;
import com.exez.gradientshop.util.GradientUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class NameColorShopMenu extends AbstractMenu {

    private static final int PAGE_SIZE = 21;
    private static final int[] SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private final int page;
    private List<String> ids;

    public NameColorShopMenu(GradientShopPlugin plugin, Player player, int page) {
        super(plugin, player);
        this.page = page;
    }

    @Override
    public void build() {
        ids = new ArrayList<>(plugin.getShopConfig().getNameColors().keySet());
        String title = color(plugin.getConfig().getString("gui-titles.namecolors").replace("%page%", String.valueOf(page)));
        inventory = Bukkit.createInventory(this, 54, title);
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);

        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        int start = (page - 1) * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, ids.size());

        for (int i = start; i < end; i++) {
            String id = ids.get(i);
            ShopEntry entry = plugin.getShopConfig().getNameColors().get(id);
            boolean owned = data.getOwnedNameColors().contains(id);
            boolean selected = id.equals(data.getActiveNameColor());

            String status = selected ? "&aTANLANGAN" : (owned ? "&2SOTIB OLINGAN" : "&cSOTIB OLINMAGAN");
            String nickPreview = GradientUtil.single(player.getName(), entry.from);
            String textPreview = GradientUtil.single(
                    plugin.getConfig().getString("preview.text-sample"), entry.from);
            String colorName = GradientUtil.single(entry.name, entry.from);

            List<String> lore = new ArrayList<>();
            lore.add("&7Narx: &e" + entry.price + " token");
            lore.add("&7Holat: " + status);
            lore.add(nickPreview);
            lore.add(textPreview);
            lore.add("");
            lore.add(owned ? "&a▶ Bosib tanlang" : "&a▶ Bosib sotib oling");

            inventory.setItem(SLOTS[i - start], item(Material.ALLIUM, colorName, lore));
        }

        inventory.setItem(45, item(Material.RED_DYE, "&cORQAGA", null));
        inventory.setItem(49, item(Material.CHEST, "&6BOSH MENYU", null));
        inventory.setItem(53, item(Material.PINK_DYE, "&dOLINGAN NAME COLOR", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        if (slot == 45 || slot == 49) { openMenu(new MainMenu(plugin, player)); return; }
        if (slot == 53) { openMenu(new OwnedNameColorsMenu(plugin, player, 1)); return; }

        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] == slot) {
                int index = (page - 1) * PAGE_SIZE + i;
                if (index >= ids.size()) return;
                handlePurchaseOrSelect(ids.get(index));
                return;
            }
        }
    }

    private void handlePurchaseOrSelect(String id) {
        PlayerData data = plugin.getDataManager().get(player.getUniqueId());
        ShopEntry entry = plugin.getShopConfig().getNameColors().get(id);

        if (data.getOwnedNameColors().contains(id)) {
            data.setActiveNameColor(id);
            data.setNameColorEnabled(true);
            player.sendMessage(color(plugin.getConfig().getString("messages.activated")
                    .replace("%name%", entry.name)));
        } else {
            if (!plugin.getEconomy().has(player.getUniqueId(), entry.price)) {
                player.sendMessage(color(plugin.getConfig().getString("messages.not-enough-tokens")
                        .replace("%price%", String.valueOf(entry.price))));
                return;
            }
            plugin.getEconomy().take(player.getUniqueId(), entry.price);
            data.getOwnedNameColors().add(id);
            data.addSpentTokens(entry.price);
            data.setActiveNameColor(id);
            data.setNameColorEnabled(true);
            player.sendMessage(color(plugin.getConfig().getString("messages.purchased")
                    .replace("%name%", entry.name)));
        }
        plugin.getDataManager().save(data);
        openMenu(new NameColorShopMenu(plugin, player, page));
    }
}
