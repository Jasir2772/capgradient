package com.exez.gradientshop.gui;

import com.exez.gradientshop.GradientShopPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class OwnedHubMenu extends AbstractMenu {

    public OwnedHubMenu(GradientShopPlugin plugin, Player player) {
        super(plugin, player);
    }

    @Override
    public void build() {
        inventory = Bukkit.createInventory(this, 27, color("&8OLINGANLARIM"));
        fillBorder(Material.GRAY_STAINED_GLASS_PANE);
        inventory.setItem(11, item(Material.ORANGE_DYE, "&6Olingan gradientlar", List.of("&7Sotib olganlaringiz.")));
        inventory.setItem(13, item(Material.CORNFLOWER, "&9Olingan fontlar", List.of("&7Sotib olganlaringiz.")));
        inventory.setItem(15, item(Material.ALLIUM, "&dOlingan name colorlar", List.of("&7Sotib olganlaringiz.")));
        inventory.setItem(22, item(Material.RED_DYE, "&cOrqaga", null));
    }

    @Override
    public void onClick(int slot, ItemStack clicked) {
        switch (slot) {
            case 11 -> openMenu(new OwnedGradientsMenu(plugin, player, 1));
            case 13 -> openMenu(new OwnedFontsMenu(plugin, player, 1));
            case 15 -> openMenu(new OwnedNameColorsMenu(plugin, player, 1));
            case 22 -> openMenu(new MainMenu(plugin, player));
        }
    }
}
